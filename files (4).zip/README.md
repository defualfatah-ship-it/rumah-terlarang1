# Rumah Terlarang

Game horor 3D first-person di browser (three.js). Satu file HTML, tanpa instalasi.

## Cara main
- Buka `index.html` di browser (Chrome/Edge disarankan), atau lewat GitHub Pages.
- Klik layar untuk mengunci mouse. Tekan Esc untuk melepas (game otomatis pause).
- Kontrol: W A S D jalan · Mouse lihat · E interaksi/sembunyi · Shift lari · P pause · H petunjuk
- Stik PS: stik kiri jalan · stik kanan lihat · X interaksi · R2/L3 lari · Segitiga petunjuk · Options pause
- Mode 2 pemain (layar terbelah): P1 keyboard+mouse, P2 stik PS atau panah+Enter+Shift kanan.

## Tujuan
Temukan 5 kunci dan 5 petunjuk, pecahkan 3 teka-teki, buka ruang rahasia, ambil Kunci Utama, lalu keluar. Maksimal tertangkap 5 kali.

## Pasang di GitHub Pages
1. Buat repository baru, upload `index.html` dan `README.md` (nama `index.html` jangan diubah).
2. Settings > Pages > Source: Deploy from a branch > `main` / `(root)` > Save.
3. Buka `https://USERNAME.github.io/NAMA-REPO/` (tunggu 1-2 menit).

## Catatan
- Butuh internet (three.js dimuat dari cdnjs.cloudflare.com).
- Mouse lock dan stik PS berjalan normal di GitHub Pages atau saat file dibuka langsung. Di tampilan sematan (iframe) browser bisa memblokirnya.
- Jika setelah update tampilan masih lama, muat ulang dengan Ctrl+Shift+R.
- Mengandung jumpscare dan suara keras.
